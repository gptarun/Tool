import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router, NavigationEnd } from '../../../node_modules/@angular/router';
import { Location } from '../../../node_modules/@angular/common';
import { ProgressService } from '../visual/progress.service';
import { MatDialog } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { IntroWindowComponent } from '../intro-window/intro-window.component';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css'], 
})

export class FooterComponent implements OnInit {
  hideElement = false;
  user: any;
  @Input('name') teamName: string;

  constructor(public progress: ProgressService,
    public router: Router) {
    this.router.events.subscribe((val) => {

      if (val instanceof NavigationEnd) {
        if (val.url.includes('/start')) {
          this.hideElement = false;
        }
        else {
          this.hideElement = false;
        }
      }
    }
    )
  }
  ngOnInit() {
  }
}
export class signupcomponent {
  public team_name: any;
  constructor (public navCtrl: NavController)
}




